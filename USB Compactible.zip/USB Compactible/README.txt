Summary of Scripts

1. MoveFiles.bat
This script copies or moves the required files (such as the executable and 
support scripts) from the USB drive into the computer. It places them in 
specific folders such as the Public folder or the Startup folder so they 
can be accessed or run later.

Purpose:
Set up the required files on the system.

----------------------------------------------------

2. GetFiles.bat
This script retrieves files from the computer and moves them back to the 
USB drive where the script is running. It is mainly used to collect files 
that were previously placed on the system.

Purpose:
Collect files from the system and store them on the USB drive.

----------------------------------------------------

3. GetLogs.bat
This script retrieves the log file (keylogs.txt) from the Public folder.

Steps performed:
1. Stops the running program so the log file is not locked.
2. Moves the log file to the USB drive.
3. Restarts the program again so logging continues.

Purpose:
Safely retrieve log data while allowing the program to continue running.

----------------------------------------------------

Overall Workflow

movefiles.bat  -> places files on the system
getlogs.bat    -> collects the generated logs
getfiles.bat   -> retrieves other related files

These scripts automate copying, retrieving, and maintaining files between
the computer and the USB drive.